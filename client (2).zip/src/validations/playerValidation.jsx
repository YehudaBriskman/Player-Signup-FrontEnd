import z, { number, string } from "zod"

const signUpPlayerValidation = z.object({
    name: string().min(3, { message: "must be atlist 3 notes" }),
    password: string().min(4, { message: "password must be atlist 4 notes" }),
    playerType: string()

})

const abilitysPlayerValidation = z.object({
    ability1: string(),
    ability2: string(),
    ability3: string(),
    ability4: string(),
    ability5: string()
})

const abilitysLevelValidation = z.object({
    ability1Level: number(),
    ability2Level: number(),
    ability3Level: number(),
    ability4Level: number(),
    ability5Level: number()
})

export { signUpPlayerValidation, abilitysPlayerValidation, abilitysLevelValidation }