const BASE_URL="http://localhost:3001/"


//user routs
const REGISTER_URL ="user/register"
const LOGIN_URL ="user/login"
const DELETEUSER_URL = "user/deleteacount"
const REGISTER_PLAYER_URL="player/register"
const LOGIN_PLAYER_URL ="player/login"


export{BASE_URL as default,REGISTER_URL,LOGIN_URL,DELETEUSER_URL,REGISTER_PLAYER_URL,LOGIN_PLAYER_URL}