// PlayerAbilitys.jsx
import React, { useContext, useEffect } from 'react';
import PlayerContext from '../context/playerContext';
import { useNavigate } from 'react-router-dom'
import Loading from '../../shared/Loading'
import { useForm } from 'react-hook-form'
import { zodResolver } from "@hookform/resolvers/zod"
import { abilitysPlayerValidation } from '../../validations/playerValidation'

const PlayerAbilitys = () => {

  const { player, setPlayer } = useContext(PlayerContext)
  const type = player.playerType;
  const ability2 = "speed"
  const ability3 = "healing"
  const options5 = []
  
  const choos5 = (op1, op2, op3, op4) => {
    console.log(options5);
    options5.push(op1)
    options5.push(op2)
    options5.push(op3)
    options5.push(op4)
    
  }
  
  const choos5ForMage = (op1, op2, op3, op4, op5, op6) => {
    options5.push(op1)
    options5.push(op2)
    options5.push(op3)
    options5.push(op4)
    options5.push(op5)
    options5.push(op6)
  }
  
  const abilitysPerType = (type) => {
    
    if (type === "mage") {
      choos5ForMage("fire", "water", "earth", "wind", "light", "darknes")
      return "magik power"
    } else if (type === "sword-man") {
      choos5("sky-walking", "increased-regeneration", "increased-physicality", "divine-speed")
      return "power"
    } else if (type === "bow-man") {
      choos5("sky-walking", "increased-regeneration", "rapid-fire", "divine-speed")
      return "vision"
    } else if (type === "healer") {
      choos5("sky-walking", "increased-regeneration", "multiple-healing", "infinite-mana")
      return "divine-mercy"
    }
    else {
      return "error"
    }
  }
  
  
  
  const ability1 = abilitysPerType(type)
  const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
    resolver: zodResolver(abilitysPlayerValidation),
    mode: 'onSubmit',
    reValidateMode: 'onChange',
    defaultValues:{
      ability1: ability1,
      ability2: ability2,
      ability3: ability3
    }
  });
  


  const nav = useNavigate()
  const signup = async (data) => {
    const detailsUpdate = data
    console.log("update: ",detailsUpdate);
    setPlayer({...player,...detailsUpdate})
    nav('/playerLevelAbilitys');
  };

  return (
    <>
      <Loading on={isSubmitting} />
      <div className="max-w-md mx-auto mt-8 p-8 bg-white rounded shadow-md">
        <h2 className="text-2xl font-semibold mb-4">Player Abilitys</h2>
        <form onSubmit={handleSubmit(signup)}>
          <div className="mb-6">
            {
              errors && <span className='text-red-600'>{errors?.error?.message}</span>
            }
            <h2
              className="w-full border p-2 rounded focus:outline-none focus:border-blue-500"
            >
              {ability1}
            </h2>
          </div>
          <div className="mb-6">
            <h2
              className="w-full border p-2 rounded focus:outline-none focus:border-blue-500">
              {ability2}
            </h2>
          </div>
          <div className="mb-6">
            <h2
              className="w-full border p-2 rounded focus:outline-none focus:border-blue-500">
              {ability3}
            </h2>
          </div>
          <div className="mb-6">
            <label htmlFor="ability4" className="block text-gray-600 text-sm font-medium mb-2">
              Please choose your spacial magik ability
            </label>
            <select
              name='ability4'
              className="w-full border p-2 rounded focus:outline-none focus:border-blue-500"
              {...register("ability4")}
            >
              <option value="fire">Fire</option>
              <option value="water">Water</option>
              <option value="air">Air</option>
              <option value="land">Land</option>
              <option value="light">Light</option>
              <option value="darknes">Darknes</option>
            </select>
          </div>
          <div className="mb-6">
            <label htmlFor="ability5" className="block text-gray-600 text-sm font-medium mb-2">
              Please choose your spacial ability
            </label>
            <select
              name='ability5'
              className="w-full border p-2 rounded focus:outline-none focus:border-blue-500"
              {...register("ability5")}
            >
              <option value={options5[0]}>{options5[0]}</option>
              <option value={options5[1]}>{options5[1]}</option>
              <option value={options5[2]}>{options5[2]}</option>
              <option value={options5[3]}>{options5[3]}</option>
              {options5.length > 4 && <option value={options5[4]}>{options5[4]}</option>}
              {options5.length > 5 && <option value={options5[5]}>{options5[5]}</option>}
            </select>

          </div>
          <button
            type="submit"
            className="w-full bg-blue-500 text-white p-3 rounded focus:outline-none hover:bg-blue-600"
          >
            Next
          </button>
          {errors.error && <span className='text-red-600'>{errors.error.message}</span>}
        </form>
      </div>
    </>
  );
};

export default PlayerAbilitys;
