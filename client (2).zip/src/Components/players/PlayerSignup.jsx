import React, { useContext, useState } from 'react'
import Loading from '../../shared/Loading'
import { useForm } from 'react-hook-form'
import { zodResolver } from "@hookform/resolvers/zod"
import { signUpPlayerValidation } from '../../validations/playerValidation'
import PlayerContext from '../context/playerContext'
import { useNavigate } from 'react-router-dom'


const PlayerSignup = () => {
    const {player,setPlayer}=useContext(PlayerContext)
    const { register, handleSubmit, formState: { errors, isSubmitting } } = useForm({
        resolver: zodResolver(signUpPlayerValidation),
        mode: "onSubmit",
        reValidateMode: "onChange"
    });

    //              !!!Player לזכור להעביר את זה ואת הגט אקסיוס סטטוס לקומפוננטה האחרונה שמציגה את ה 

    const nav = useNavigate()
    const signup = async (data) => {
        const detailsUpdate = data
        console.log("update: ",detailsUpdate);
        setPlayer({...player,...detailsUpdate})
        nav("/playerAbilitys")
    }


    return (
        <>
            <Loading on={isSubmitting} />
            <div className="max-w-md mx-auto mt-8 p-8 bg-white rounded shadow-md">
                <h2 className="text-2xl font-semibold mb-4">Sign Up</h2>
                <form onSubmit={handleSubmit(signup)}>
                    <div className="mb-4">
                        <label htmlFor="name" className="block text-gray-600 text-sm font-medium mb-2">
                            Player Name
                        </label>
                        <input
                            className="w-full border p-2 rounded focus:outline-none focus:border-blue-500"
                            {...register("name")}
                            placeholder="NAME"
                        />
                        {errors.name &&
                            <span className='text-red-600'>{errors.name.message}</span>}
                    </div>
                    <div className="mb-6">
                        <label htmlFor="password" className="block text-gray-600 text-sm font-medium mb-2">
                            Password
                        </label>
                        <input
                            type="password"
                            className="w-full border p-2 rounded focus:outline-none focus:border-blue-500"
                            {...register("password")}
                        />
                        {errors.password &&
                            <span className='text-red-600'>{errors.password.message}</span>}
                    </div>
                    <div className="mb-6">
                        <label htmlFor="playerType" className="block text-gray-600 text-sm font-medium mb-2">
                            Player Type
                        </label>
                        <select
                            className="w-full border p-2 rounded focus:outline-none focus:border-blue-500"
                            {...register("playerType")}
                        >
                            <option value="mage">Mage</option>
                            <option value="sword-man">Sword Man</option>
                            <option value="bow-man">Bow Man</option>
                            <option value="healer">Healer</option>
                        </select>
                    </div>
                    <button
                        type="submit"
                        className="w-full bg-blue-500 text-white p-3 rounded focus:outline-none hover:bg-blue-600"
                    >
                        Next
                    </button>
                    {errors.error && <span className='text-red-600'>{errors.error.message}</span>}
                </form>
            </div>
        </>
    )
}
export default PlayerSignup


PlayerSignup.jsx




