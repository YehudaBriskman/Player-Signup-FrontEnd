import React, { useContext, useState } from 'react';
import PlayerContext from '../context/playerContext';
import { useNavigate } from 'react-router-dom'
import Loading from '../../shared/Loading'
import { useForm } from 'react-hook-form'
import { zodResolver } from "@hookform/resolvers/zod"
import { abilitysLevelValidation } from '../../validations/playerValidation'



const PlayerLevelAbilitys = () => {


  const { player, setPlayer } = useContext(PlayerContext)
  const [updatePoints, setUpdatePoints] = useState(5);





  const updatinglevel = (event) => {
    const currentValue = parseInt(event.target.value);
    const previousValue = parseInt(event.target.dataset.previousValue);

    if (!isNaN(previousValue)) {
      if (currentValue > previousValue && updatePoints > 0) {
        setUpdatePoints((prev) => prev - 1);
        console.log('Value increased');
      } else if (currentValue < previousValue) {
        setUpdatePoints((prev) => prev + 1);
        console.log('Value decreased');
      } else {
        console.log('Value remains the same');
      }
    } else if (isNaN(previousValue)) {
      setUpdatePoints((prev) => prev - 1);
      console.log('Value increased');
    }
    event.target.dataset.previousValue = currentValue;
  }





  const { register, handleSubmit, watch, formState: { errors, isSubmitting } } = useForm ({
    resolver: zodResolver(abilitysLevelValidation),
    mode: 'onSubmit',
    reValidateMode: 'onChange'
  });


  const nav = useNavigate()
  const signup = async (data) => {
    const detailsUpdate = data
    console.log("update: ", detailsUpdate);
    setPlayer({ ...player, ...detailsUpdate })
    nav('/');
  };



  return (
    <div>
      <Loading on={isSubmitting} />
      <div className="max-w-lg mx-auto mt-8 p-8 bg-white rounded shadow-md text-center">
        <h2 className="text-2xl font-semibold mb-8">Player Abilitys Level</h2>
        <form onSubmit={handleSubmit(signup)}>
          <h2>Please choose abilitys to upgrade</h2>
          <h3>Points Left: {updatePoints}</h3>
          <div className='flex flex-wrap justify-around p-6'>
            <div className="mb-4 flex justify-between" >
              <div className="mb-4 flex justify-center items-center max-w-[50%] ">
                <label htmlFor="ability1Level" className="block text-gray-600 me-2 text-lg mb-2 pt-1" >
                  {player.ability1} level:
                </label>
                <input
                  type='number'
                  defaultValue={1}
                  min={1}
                  className="w-[30%] border ps-2 py-2 rounded focus:outline-none focus:border-blue-500"
                  {...register("ability1Level",{valueAsNumber:true})}
                  max={updatePoints > 0 ? 15 : watch("ability1Level")}
                  onChange={
                    updatinglevel
                  }
                />
              </div>
              <div className="mb-4 flex justify-center items-center max-w-[50%] ">
                <label htmlFor="ability2Level" className="block text-gray-600 me-2 text-lg mb-2 pt-1">
                  {player.ability2} level:
                </label>
                <input
                  type='number'
                  defaultValue={1}
                  min={1}
                  className="w-[30%] border ps-2 py-2 rounded focus:outline-none focus:border-blue-500"
                  {...register("ability2Level",{valueAsNumber:true})}
                  max={updatePoints > 0 ? 15 : watch("ability2Level")}
                  onChange={
                    updatinglevel
                  }
                />
              </div>
            </div>
            <div className="mb-4 flex justify-between" >
              <div className="mb-4 flex justify-center items-center max-w-[50%] ">
                <label htmlFor="ability3Level" className="block text-gray-600 me-2 text-lg mb-2 pt-1" >
                  {player.ability3} level:
                </label>
                <input
                  type='number'
                  defaultValue={1}
                  min={1}
                  className="w-[30%] border ps-2 py-2 rounded focus:outline-none focus:border-blue-500"
                  {...register("ability3Level",{valueAsNumber:true})}
                  max={updatePoints > 0 ? 15 : watch("ability3Level")}
                  onChange={
                    updatinglevel
                  }
                />
              </div>
              <div className="mb-4 flex justify-center items-center max-w-[50%] ">
                <label htmlFor="ability4Level" className="block text-gray-600 me-2 text-lg mb-2 pt-1">
                  {player.ability4} level:
                </label>
                <input
                  type='number'
                  defaultValue={1}
                  min={1}
                  className="w-[30%] border ps-2 py-2 rounded focus:outline-none focus:border-blue-500"
                  {...register("ability4Level",{valueAsNumber:true})}
                  max={updatePoints > 0 ? 15 : watch("ability4Level")}
                  onChange={
                    updatinglevel
                  }
                />
              </div>
            </div>
            <div className="mb-4 flex justify-center items-center max-w-[50%] ">
              <label htmlFor="ability5Level" className="block text-gray-600 me-2 text-lg mb-2 pt-1">
                {player.ability5} level:
              </label>
              <input
                type='number'
                defaultValue={1}
                min={1}
                className="w-[30%] border ps-2 py-2 rounded focus:outline-none focus:border-blue-500"
                {...register("ability5Level",{valueAsNumber:true})}
                max={updatePoints > 0 ? 15 : watch("ability5Level")}
                onChange={
                  updatinglevel
                }
              />
            </div>
          </div>


          {errors.ability2Level && <span className='text-red-600'>{errors.ability2Level.message}</span>}
          {errors.ability1Level && <span className='text-red-600'>{errors.ability2Level.message}</span>}

          <button
            type="submit"
            className="w-full bg-blue-500 text-white p-3 rounded focus:outline-none hover:bg-blue-600"
          >
            Next
          </button>
          {errors.error && <span className='text-red-600'>{errors.error.message}</span>}
        </form>
      </div>
    </div>
  )
}

export default PlayerLevelAbilitys