import React from 'react'
import { Outlet } from 'react-router-dom'

const Home = () => {
  return (
    <h1>home</h1>
  )
}

export default Home