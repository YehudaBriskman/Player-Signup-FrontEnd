import { createContext } from "react";

const PlayerContext = createContext();

export default PlayerContext;