import React from 'react'
import { Link, Outlet } from 'react-router-dom'

const Navbar = () => {
    return (
        <>
            <header className='pb-6'>
                <nav className='bg-slate-900 p-4 d-flex justify-content-end'>
                    <div className='p-4 d-flex ms-auto'>
                        <Link className='text-white mx-3' to="/">HOME</Link>
                        <Link className='text-white mx-3' to="/signup">SIGNUP</Link>
                        <Link className='text-white mx-3' to="/login">LOGIN</Link>
                        <Link className='text-white mx-3' to="/deleteacount">DELETE ACOUNT</Link>
                        <Link className='text-white mx-3' to="/playerSignup">PLAYERS</Link>
                    </div>
                </nav>
            </header>
            <Outlet />
        </>
    )
}

export default Navbar